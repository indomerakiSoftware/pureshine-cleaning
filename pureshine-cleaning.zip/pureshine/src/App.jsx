import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence, MotionConfig, useReducedMotion } from "framer-motion";

const ease = [0.22, 1, 0.36, 1];
const wrap = "mx-auto max-w-7xl px-5 sm:px-8";

const Reveal = ({ children, delay = 0, className = "" }) => (
  <motion.div className={className} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-70px" }} transition={{ duration: 0.8, delay, ease }}>{children}</motion.div>
);

const Btn = ({ href, children, variant = "solid", className = "", ...p }) => (
  <motion.a href={href} whileHover={{ y: -2 }} whileTap={{ scale: 0.97 }} {...p}
    className={`inline-flex items-center justify-center rounded-full px-7 py-3.5 text-sm font-semibold transition-colors ${
      variant === "solid" ? "bg-citrus text-lagoon hover:bg-white" : variant === "dark" ? "bg-lagoon text-white hover:bg-slate" : "border border-current/30 hover:border-current hover:bg-white/10"} ${className}`}>
    {children}
  </motion.a>
);

const H2 = ({ children, className = "" }) => (
  <h2 className={`font-display text-4xl font-semibold leading-[1.02] tracking-tight sm:text-5xl lg:text-6xl ${className}`}>{children}</h2>
);

/* ---------- Illustrated scene (swap for real photos) ---------- */
const grime = "radial-gradient(circle at 20% 30%,rgba(70,55,25,.6),transparent 34%),radial-gradient(circle at 72% 58%,rgba(70,55,25,.55),transparent 38%),radial-gradient(circle at 42% 88%,rgba(70,55,25,.5),transparent 30%)";
const Spark = ({ className, delay = 0 }) => {
  const reduce = useReducedMotion();
  return (
    <motion.svg aria-hidden viewBox="0 0 100 100" className={`absolute ${className}`} style={reduce ? { opacity: 0.8 } : undefined}
      animate={reduce ? undefined : { scale: [0.5, 1, 0.5], opacity: [0.25, 1, 0.25], rotate: [0, 45, 0] }}
      transition={{ duration: 3.6, delay, repeat: Infinity, ease: "easeInOut" }}>
      <path d="M50 0C54 30 70 46 100 50 70 54 54 70 50 100 46 70 30 54 0 50 30 46 46 30 50 0Z" fill="#fff" />
    </motion.svg>
  );
};
function Scene({ clean }) {
  const reduce = useReducedMotion();
  return (
    <div className="absolute inset-0 overflow-hidden" style={{ background: clean ? "linear-gradient(135deg,#0a3340,#16616b 55%,#8fd3c6)" : "linear-gradient(135deg,#46544f,#6a726a 60%,#8b8a76)" }}>
      <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "linear-gradient(rgba(255,255,255,.6) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.6) 1px,transparent 1px)", backgroundSize: "64px 64px" }} />
      {clean ? (
        <>
          <div className="absolute -top-1/4 left-1/3 h-[150%] w-24 rotate-[22deg] bg-white/15 blur-xl" />
          <div className="absolute -top-1/4 left-1/2 h-[150%] w-12 rotate-[22deg] bg-white/10 blur-lg" />
          <Spark className="left-[14%] top-[18%] h-8 w-8" /><Spark className="right-[18%] top-[30%] h-12 w-12" delay={1} />
          <Spark className="bottom-[22%] left-[40%] h-6 w-6" delay={2} /><Spark className="bottom-[14%] right-[12%] h-9 w-9" delay={0.6} />
          {!reduce && [...Array(10)].map((_, i) => (
            <motion.span key={i} className="absolute bottom-0 rounded-full border border-white/60 bg-white/15"
              style={{ left: `${(i * 41) % 96}%`, width: 10 + ((i * 13) % 30), height: 10 + ((i * 13) % 30) }}
              animate={{ y: [0, -460], opacity: [0, 0.9, 0] }} transition={{ duration: 6 + (i % 5), delay: i * 0.7, repeat: Infinity, ease: "linear" }} />
          ))}
        </>
      ) : <div className="absolute inset-0" style={{ backgroundImage: grime }} />}
    </div>
  );
}

/* ---------- Navbar ---------- */
const links = [["Services", "services"], ["Why us", "why"], ["Process", "process"], ["Results", "results"], ["Reviews", "reviews"], ["Areas", "areas"], ["FAQ", "faq"]];
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 24);
    f(); window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  return (
    <motion.header initial={{ y: -80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.8, ease }}
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled || open ? "bg-porcelain/85 py-3 shadow-[0_10px_30px_-15px_rgba(10,51,64,.35)] backdrop-blur-xl" : "py-6"}`}>
      <nav className={`${wrap} flex items-center justify-between`} aria-label="Main">
        <a href="#top" className="font-display text-xl font-bold tracking-tight">PureShine <span className="font-medium text-slate">Cleaning Co.</span></a>
        <ul className="hidden items-center gap-8 text-sm font-medium lg:flex">
          {links.map(([l, id]) => (
            <li key={id}><a href={`#${id}`} className="relative py-1 after:absolute after:inset-x-0 after:-bottom-0.5 after:h-0.5 after:origin-left after:scale-x-0 after:bg-lagoon after:transition-transform hover:after:scale-x-100">{l}</a></li>
          ))}
        </ul>
        <div className="flex items-center gap-3">
          <span className="hidden sm:block"><Btn href="#quote" variant="dark">Get a Free Quote</Btn></span>
          <button aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(!open)} className="grid h-11 w-11 place-items-center rounded-full border border-lagoon/20 lg:hidden">
            <span className="block space-y-1.5">
              <i className={`block h-0.5 w-5 bg-lagoon transition ${open ? "translate-y-2 rotate-45" : ""}`} />
              <i className={`block h-0.5 w-5 bg-lagoon transition ${open ? "opacity-0" : ""}`} />
              <i className={`block h-0.5 w-5 bg-lagoon transition ${open ? "-translate-y-2 -rotate-45" : ""}`} />
            </span>
          </button>
        </div>
      </nav>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="max-h-[calc(100dvh-4.5rem)] overflow-y-auto lg:hidden">
            <ul className={`${wrap} py-4`}>
              {links.map(([l, id]) => <li key={id}><a onClick={() => setOpen(false)} href={`#${id}`} className="block border-b border-lagoon/10 py-3.5 font-display text-2xl font-medium">{l}</a></li>)}
              <li><Btn href="#quote" onClick={() => setOpen(false)} variant="dark" className="mt-5 w-full">Get a Free Quote</Btn></li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}

/* ---------- Hero ---------- */
function Hero() {
  const reduce = useReducedMotion();
  return (
    <section id="top" className="relative overflow-hidden pb-16 pt-28 sm:pt-36 lg:pb-24">
      <motion.div aria-hidden className="absolute -right-40 top-10 h-[420px] w-[420px] rounded-full bg-glass/60 blur-3xl" animate={{ x: [0, -40, 0], y: [0, 30, 0] }} transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }} />
      <div className={`${wrap} relative grid items-center gap-12 lg:grid-cols-[1.05fr_.95fr]`}>
        <div>
          <h1 className="font-display text-[clamp(2.4rem,10.5vw,3.4rem)] font-semibold leading-[0.98] tracking-tight sm:text-6xl lg:text-[3.6rem] xl:text-7xl">
            {["A Cleaner Space.", "A Better Life."].map((l, i) => (
              <span key={l} className="block overflow-hidden pb-2">
                <motion.span className="block" initial={{ y: "110%" }} animate={{ y: 0 }} transition={{ duration: 1, delay: 0.25 + i * 0.15, ease }}>{l}</motion.span>
              </span>
            ))}
          </h1>
          <motion.p className="mt-6 max-w-xl text-lg leading-relaxed text-slate" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.7, ease }}>
            Background-checked, insured teams who show up on time and leave every home and workplace spotless. Trusted for homes, offices, and commercial spaces across the USA.
          </motion.p>
          <motion.div className="mt-9 flex flex-col gap-3 sm:flex-row" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.85, ease }}>
            <Btn href="#quote" variant="dark">Get a Free Quote</Btn>
            <Btn href="#services" variant="ghost">Explore Our Services</Btn>
          </motion.div>
          <motion.p className="mt-8 text-sm font-medium text-slate" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2 }}>
            Rated 4.9/5 by 2,300+ customers. Satisfaction guaranteed.
          </motion.p>
        </div>
        <motion.div initial={{ opacity: 0, scale: 0.94, y: 30 }} animate={{ opacity: 1, scale: 1, y: 0 }} transition={{ duration: 1.1, delay: 0.3, ease }}
          className="relative h-[400px] overflow-hidden rounded-[2rem] bg-lagoon shadow-[0_40px_80px_-30px_rgba(10,51,64,.6)] sm:h-[560px]">
          <Scene clean />
          {!reduce && <><motion.div className="absolute inset-0" initial={{ clipPath: "inset(0 0 0 0%)" }} animate={{ clipPath: "inset(0 0 0 100%)" }} transition={{ duration: 1.9, delay: 1, ease: [0.65, 0, 0.35, 1] }}>
            <Scene />
          </motion.div>
          <motion.div aria-hidden className="absolute inset-y-0 w-1.5 bg-citrus shadow-[0_0_30px_6px_rgba(232,242,92,.6)]" initial={{ left: "0%", opacity: 1 }} animate={{ left: "100%", opacity: [1, 1, 0] }} transition={{ duration: 1.9, delay: 1, ease: [0.65, 0, 0.35, 1] }} /></>}
          <motion.div className="absolute bottom-5 left-5 right-5 rounded-2xl bg-white/90 p-4 shadow-xl backdrop-blur sm:right-auto sm:max-w-xs" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 2.6, ease }}>
            <p className="font-display text-lg font-semibold">Eco-safe. Pet-safe. Spotless.</p>
            <p className="text-sm text-slate">Every visit finishes with a quality checklist.</p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

/* ---------- Services ---------- */
const services = [
  ["Residential Cleaning", "Home", "Weekly, biweekly or one-off cleans for kitchens, baths, bedrooms and living areas."],
  ["Deep Cleaning", "Home", "Top-to-bottom detailing: baseboards, inside appliances, grout, vents and hidden dust."],
  ["Move-In / Move-Out Cleaning", "Home", "Leave a rental deposit-ready or start fresh in a new place."],
  ["Commercial Cleaning", "Business", "Retail, clinics, studios and facilities cleaned on a schedule that fits your hours."],
  ["Office Cleaning", "Business", "Desks, break rooms, restrooms and shared spaces kept professional every day."],
  ["Recurring Cleaning", "Home & Business", "A dedicated team and a set schedule, so your space is always ready."],
];
function Services() {
  return (
    <section id="services" className="py-20 sm:py-28">
      <div className={wrap}>
        <Reveal className="max-w-2xl"><H2>Cleaning for every kind of space</H2>
          <p className="mt-5 text-lg text-slate">Pick a service or combine them. Every plan is tailored to your space and priced upfront.</p></Reveal>
        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {services.map(([t, tag, d], i) => (
            <Reveal key={t} delay={i * 0.08}>
              <motion.a href="#quote" whileHover={{ y: -6 }} className="group relative block h-full overflow-hidden rounded-3xl border border-lagoon/10 bg-white p-7 transition-colors hover:border-lagoon">
                <span className="absolute inset-0 origin-bottom scale-y-0 bg-lagoon transition-transform duration-500 ease-out group-hover:scale-y-100" />
                <span className="relative block transition-colors duration-500 group-hover:text-white">
                  <span className="inline-block rounded-full bg-glass px-3 py-1 text-xs font-semibold text-lagoon">{tag}</span>
                  <span className="mt-10 block font-display text-2xl font-semibold leading-tight">{t}</span>
                  <span className="mt-3 block text-slate transition-colors duration-500 group-hover:text-glass">{d}</span>
                  <span className="mt-6 block text-sm font-semibold underline underline-offset-4">Request a quote</span>
                </span>
              </motion.a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Why us ---------- */
const why = [
  ["Vetted and insured", "Every cleaner is background-checked, trained in-house, bonded and fully insured."],
  ["Satisfaction guarantee", "Not happy with something? Tell us within 24 hours and we will re-clean it free."],
  ["Safer products", "EPA-registered, low-odor, pet-safe products. Fragrance-free on request."],
  ["Schedule that works", "Online booking, text reminders, and easy rescheduling with no long contracts."],
];
function Why() {
  return (
    <section id="why" className="bg-lagoon py-20 text-white sm:py-28">
      <div className={`${wrap} grid gap-12 lg:grid-cols-[.8fr_1.2fr]`}>
        <Reveal><H2>Clean you can count on</H2><p className="mt-5 max-w-md text-lg text-glass">Reliable is the whole job. Here is how we earn your trust, visit after visit.</p></Reveal>
        <div className="divide-y divide-white/15 border-y border-white/15">
          {why.map(([t, d], i) => (
            <Reveal key={t} delay={i * 0.06}>
              <div className="grid gap-2 py-7 sm:grid-cols-[14rem_1fr] sm:gap-8"><h3 className="font-display text-2xl font-semibold">{t}</h3><p className="text-glass">{d}</p></div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- How it works ---------- */
const steps = [["Tell us about your space", "Share size, type of clean and timing in a 2-minute form or a quick call."], ["Get a clear quote", "Receive a fixed price within hours. No surprises, no pressure."], ["Enjoy the shine", "Your vetted team arrives on schedule and finishes with a quality checklist."]];
function Steps() {
  return (
    <section id="process" className="py-20 sm:py-28">
      <div className={wrap}>
        <Reveal><H2 className="max-w-2xl">Booking takes three steps</H2></Reveal>
        <div className="relative mt-14 grid gap-10 md:grid-cols-3">
          <motion.div aria-hidden className="absolute left-0 right-0 top-6 hidden h-px origin-left bg-lagoon/25 md:block" initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 1.4, ease }} />
          {steps.map(([t, d], i) => (
            <Reveal key={t} delay={i * 0.15}>
              <div className="relative"><span className="relative grid h-12 w-12 place-items-center rounded-full bg-citrus font-display text-xl font-bold">{i + 1}</span>
                <h3 className="mt-6 font-display text-2xl font-semibold">{t}</h3><p className="mt-2 max-w-sm text-slate">{d}</p></div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Before / After ---------- */
function BeforeAfter() {
  const [p, setP] = useState(50);
  const box = useRef(null);
  const move = (e) => {
    const r = box.current.getBoundingClientRect();
    setP(Math.min(100, Math.max(0, ((e.clientX - r.left) / r.width) * 100)));
  };
  return (
    <section id="results" className="bg-glass/40 py-20 sm:py-28">
      <div className={wrap}>
        <Reveal className="max-w-2xl"><H2>See the difference</H2><p className="mt-5 text-lg text-slate">Drag the slider to compare the same space before and after a PureShine deep clean.</p></Reveal>
        <Reveal className="mt-12">
          <div ref={box} style={{ touchAction: "pan-y" }} onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); move(e); }} onPointerMove={(e) => { if (e.buttons) move(e); }}
            className="relative mx-auto h-[360px] cursor-ew-resize select-none overflow-hidden rounded-[2rem] shadow-2xl focus-within:ring-4 focus-within:ring-citrus sm:h-[520px]">
            <Scene clean />
            <div className="absolute inset-0" style={{ clipPath: `inset(0 ${100 - p}% 0 0)` }}><Scene /></div>
            <div className="pointer-events-none absolute inset-y-0 w-0.5 bg-white" style={{ left: `${p}%` }}>
              <span className="absolute left-1/2 top-1/2 grid h-12 w-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-citrus text-lg font-bold shadow-xl">&harr;</span>
            </div>
            <span className="absolute left-4 top-4 rounded-full bg-lagoon/80 px-3 py-1 text-sm font-semibold text-white">Before</span>
            <span className="absolute right-4 top-4 rounded-full bg-white/90 px-3 py-1 text-sm font-semibold">After</span>
            <input type="range" min="0" max="100" value={Math.round(p)} onChange={(e) => setP(+e.target.value)} aria-label="Before and after comparison" className="pointer-events-none absolute inset-0 h-full w-full opacity-0" />
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ---------- Testimonials ---------- */
const reviews = [
  ["They arrived on time, every time. My kitchen has never looked this good, and the team was so respectful of our home.", "Megan R.", "Austin, TX", "Recurring home cleaning"],
  ["We switched our office to PureShine last spring. Fewer complaints, happier staff, and a single invoice. Easy decision.", "David K.", "Charlotte, NC", "Office cleaning"],
  ["Our move-out clean got the full deposit back. The detail on the baseboards and appliances was impressive.", "Priya S.", "Denver, CO", "Move-out cleaning"],
];
function Reviews() {
  return (
    <section id="reviews" className="py-20 sm:py-28">
      <div className={wrap}>
        <Reveal><H2 className="max-w-2xl">Neighbors and businesses who trust us</H2></Reveal>
        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {reviews.map(([q, n, c, s], i) => (
            <Reveal key={n} delay={i * 0.1}>
              <figure className="flex h-full flex-col justify-between rounded-3xl bg-white p-8 shadow-[0_20px_50px_-30px_rgba(10,51,64,.5)]">
                <div><p role="img" aria-label="5 out of 5 stars" className="text-xl tracking-widest text-lagoon">★★★★★</p><blockquote className="mt-5 text-lg leading-relaxed">&ldquo;{q}&rdquo;</blockquote></div>
                <figcaption className="mt-8 text-sm"><span className="block font-semibold">{n}, {c}</span><span className="text-slate">{s}</span></figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Service areas ---------- */
const areas = ["Dallas, TX", "Austin, TX", "Houston, TX", "Atlanta, GA", "Charlotte, NC", "Nashville, TN", "Miami, FL", "Phoenix, AZ", "Denver, CO", "Chicago, IL", "Seattle, WA", "Boston, MA"];
function Areas() {
  return (
    <section id="areas" className="bg-lagoon py-20 text-white sm:py-28">
      <div className={`${wrap} grid gap-10 lg:grid-cols-[.8fr_1.2fr]`}>
        <Reveal><H2>Serving cities across the USA</H2><p className="mt-5 max-w-md text-lg text-glass">Do not see your city? Request a quote anyway. We are expanding every month.</p></Reveal>
        <div className="flex flex-wrap content-start gap-3">
          {areas.map((a, i) => (
            <motion.span key={a} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.04, duration: 0.5, ease }}
              whileHover={{ y: -3 }} className="rounded-full border border-white/25 px-5 py-3 text-base font-medium transition-colors hover:bg-citrus hover:text-lagoon">{a}</motion.span>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- FAQ ---------- */
const faqs = [
  ["Are your cleaners insured and background-checked?", "Yes. Every team member passes a background check and is covered by our bonding and liability insurance."],
  ["Do I need to be home during the cleaning?", "No. Many customers give us access with a door code or key. Others prefer to be home. Both work well."],
  ["Do I need to provide supplies?", "No. We bring professional equipment and eco-friendly products. If you prefer your own, just tell us."],
  ["How is pricing determined?", "By space size, condition, and service type. You get a fixed quote upfront with no hidden fees."],
  ["What if I am not satisfied?", "Contact us within 24 hours and we will return to fix it at no charge."],
  ["Can I cancel or reschedule?", "Yes. Reschedule or cancel with 24 hours notice. Recurring plans have no long-term contracts."],
];
function FAQ() {
  const [o, setO] = useState(0);
  return (
    <section id="faq" className="py-20 sm:py-28">
      <div className={`${wrap} grid gap-10 lg:grid-cols-[.8fr_1.2fr]`}>
        <Reveal><H2>Questions, answered</H2></Reveal>
        <div className="divide-y divide-lagoon/15 border-y border-lagoon/15">
          {faqs.map(([q, a], i) => (
            <div key={q}>
              <button aria-expanded={o === i} onClick={() => setO(o === i ? -1 : i)} className="flex w-full items-center justify-between gap-6 py-6 text-left font-display text-xl font-semibold">
                {q}<motion.span animate={{ rotate: o === i ? 45 : 0 }} className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-glass text-xl">+</motion.span>
              </button>
              <AnimatePresence initial={false}>
                {o === i && <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.4, ease }} className="overflow-hidden"><p className="max-w-xl pb-6 text-slate">{a}</p></motion.div>}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Final CTA + form ---------- */
function QuoteForm() {
  const [sent, setSent] = useState(false);
  const f = "w-full rounded-xl border border-lagoon/15 bg-white px-4 py-3.5 text-lagoon placeholder:text-slate/60";
  return (
    <AnimatePresence mode="wait">
      {sent ? (
        <motion.div key="ok" role="status" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="rounded-3xl bg-white p-8 text-lagoon">
          <p className="font-display text-2xl font-semibold">Request received.</p><p className="mt-2 text-slate">We will send your fixed quote within a few business hours.</p>
        </motion.div>
      ) : (
        <motion.form key="form" exit={{ opacity: 0 }} onSubmit={(e) => { e.preventDefault(); setSent(true); }} className="grid gap-3 rounded-3xl bg-white p-6 text-lagoon sm:p-8">
          <input required name="name" autoComplete="name" placeholder="Full name" aria-label="Full name" className={f} />
          <input required type="email" name="email" autoComplete="email" placeholder="Email address" aria-label="Email address" className={f} />
          <input type="tel" name="phone" autoComplete="tel" placeholder="Phone (optional)" aria-label="Phone" className={f} />
          <select required name="service" aria-label="Service" className={f} defaultValue="">
            <option value="" disabled>Select a service</option>{services.map(([t]) => <option key={t}>{t}</option>)}
          </select>
          <motion.button type="submit" whileHover={{ y: -2 }} whileTap={{ scale: 0.97 }} className="mt-1 rounded-full bg-lagoon px-7 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-slate">Get a Free Quote</motion.button>
        </motion.form>
      )}
    </AnimatePresence>
  );
}
function FinalCTA() {
  return (
    <section id="quote" className="px-3 pb-4 sm:px-5">
      <div className="relative mx-auto max-w-7xl overflow-hidden rounded-[2.5rem] bg-lagoon px-6 py-16 text-white sm:px-14 sm:py-24">
        <motion.div aria-hidden className="absolute -left-20 -top-20 h-80 w-80 rounded-full bg-citrus/20 blur-3xl" animate={{ x: [0, 60, 0], y: [0, 40, 0] }} transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }} />
        <div className="relative grid items-center gap-12 lg:grid-cols-2">
          <Reveal><H2>Ready for a space that feels brand new?</H2><p className="mt-5 max-w-md text-lg text-glass">Get a free, no-obligation quote. Most replies go out within a few hours.</p></Reveal>
          <Reveal delay={0.1}><QuoteForm /></Reveal>
        </div>
      </div>
    </section>
  );
}

/* ---------- Footer ---------- */
function Footer() {
  const col = "space-y-3 text-slate";
  return (
    <footer className="pt-20">
      <div className={`${wrap} grid gap-10 pb-12 sm:grid-cols-2 lg:grid-cols-4`}>
        <div className="lg:col-span-1"><p className="font-display text-2xl font-bold">PureShine Cleaning Co.</p><p className="mt-3 max-w-xs text-slate">Reliable residential and commercial cleaning, backed by a satisfaction guarantee.</p></div>
        <div><h3 className="mb-4 font-display text-lg font-semibold">Services</h3><ul className={col}>{services.map(([t]) => <li key={t}><a className="hover:text-lagoon hover:underline" href="#services">{t}</a></li>)}</ul></div>
        <div><h3 className="mb-4 font-display text-lg font-semibold">Contact</h3><ul className={col}>
          <li><a className="hover:underline" href="tel:+18005550142">(800) 555-0142</a></li><li><a className="hover:underline" href="mailto:hello@pureshinecleaning.com">hello@pureshinecleaning.com</a></li><li>Mon-Sat, 7am-7pm</li></ul></div>
        <div><h3 className="mb-4 font-display text-lg font-semibold">Follow</h3><ul className={col}>
          {[["Instagram", "https://www.instagram.com/"], ["Facebook", "https://www.facebook.com/"], ["LinkedIn", "https://www.linkedin.com/"], ["Google Reviews", "https://www.google.com/maps"]].map(([s, u]) => <li key={s}><a className="hover:text-lagoon hover:underline" href={u} target="_blank" rel="noopener noreferrer">{s}</a></li>)}</ul></div>
      </div>
      <div className={`${wrap} flex flex-col justify-between gap-2 border-t border-lagoon/15 py-6 text-sm text-slate sm:flex-row`}>
        <p>&copy; {new Date().getFullYear()} PureShine Cleaning Co. All rights reserved.</p><p>Licensed, bonded and insured.</p>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6 }}>
        <Navbar />
        <main><Hero /><Services /><Why /><Steps /><BeforeAfter /><Reviews /><Areas /><FAQ /><FinalCTA /></main>
        <Footer />
      </motion.div>
    </MotionConfig>
  );
}
