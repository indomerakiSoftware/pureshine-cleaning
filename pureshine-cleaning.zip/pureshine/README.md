# PureShine Cleaning Co.
npm install && npm run dev   (build: npm run build)
Placeholders to replace: phone/email, reviews, city list, stats, and the illustrated before/after scene (swap `Scene` in src/App.jsx for real photos).
The quote form is front-end only; connect it to Formspree, Resend, or your own API in `QuoteForm`.
